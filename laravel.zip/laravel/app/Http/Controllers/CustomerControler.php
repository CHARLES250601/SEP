<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerControler extends Controller
{
    public function Home()
    {
        return view('layout/main');
    }
}
