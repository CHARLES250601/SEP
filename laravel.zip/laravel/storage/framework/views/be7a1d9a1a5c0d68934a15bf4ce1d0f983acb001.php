<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="/signin.css">
  </head>

  <body class="text-center">

    <?php if($errors->any()): ?>
    <div class="error">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="alert alert-danger"><?php echo e($err); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

        <main class="form-signin">
            <form action="/doregister" method="POST">
                <?php echo csrf_field(); ?>
                <img class="mb-4" src="login.jpg" alt="" width="100" height="100">
                <h1 class="h3 mb-3 fw-normal">Please Register</h1>

                <div class="form-floating">
                    <input type="text" class="form-control" name="username" placeholder="johndoe" required >
                    <label for="floatingInput">Username</label>
                </div>

                <div class="form-floating">
                    <input type="text" class="form-control" name="name" placeholder="johndoe" required >
                    <label for="floatingInput">Name</label>
                </div>

                <div class="form-floating">
                    <input type="password" class="form-control"  name="password" placeholder="Password" required>
                    <label for="floatingPassword">Password</label>
                </div>

                <div class="form-floating">
                    <input type="email" class="form-control"  name="email" placeholder="Email" required>
                    <label for="floatingPassword">Email@example</label>
                    </div>
                </div>

                <div class="form-floating">
                    <input type="text" class="form-control"  name="alamat" placeholder="Alamat" required>
                    <label for="floatingPassword">address</label>
                    </div>
                </div>
                <br>
                <button class="w-100 btn btn-lg btn-success" type="submit">Register</button>
            </form>

        </main>

<?php if(Session::has('pesan')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('pesan')); ?></div>
<?php endif; ?>

</body>
</html>
<?php /**PATH D:\project sep\SEP\laravel\resources\views/register.blade.php ENDPATH**/ ?>